# Slice it up: Unmasking User Identities in Smartwatch Health Data

The structure of the results of our experiments is briefly described below:

## Standard DTW-Attacks
The results of the standard DTW-Attacks can be found in the folders starting with “WESAD...”. 
* *WESAD_15*: Contains the results of all DTW-Attacks on the WESAD dataset with 15 subjects.
* *WESAD-cGAN_1000*: Contains the results of all DTW-Attacks on the synthetic WESAD-cGAN dataset with 1000 subjects. 
Note: The attacks were tested for 1000 targets. Further information is listed in the corresponding folder under 
info.txt.
* *WESAD-dGAN_10000*: Contains the results of all DTW-Attacks on the synthetic WESAD-dGAN dataset with 10,000 subjects. 
Note: The attacks were tested for 15 targets.

Further structure exemplified by the WESAD_15 results:
* In the next subfolder, a distinction is made between the results for the four different downsampling factors 
DSF = {1, 10, 100, 100}.
* Next a distinction is then made between the four DTW attacks (Single, Multi, Slicing and Multi-Slicing).
* A selection can now be made, whether a complexity reduction (DBA or PCA) was applied or whether all sensors are 
analysed (Standard Processing).

A distinction is now made between the type of (interim) results:
* The calculated DTW distances for the "stress" and "non-stress" classes for all tested window sizes can be found in the 
alignments folder.
* The precision@k results can be found under result-selection-method=xxx. Depending on the DTW attack, ‘min’ or ‘mean’ 
(Multi, Slicing) or ‘min-min’, ‘mean-mean’, ‘min-mean’, ‘mean-min’ (Multi-Slicing) can be used
* In the further subdivision, the calculated realistic ranks for each sensor combination can be found in the suborder 
precision, which simplify further evaluations as intermediate results. The weighted aggregation results and the best 
window size can also be found (SW-DTW_max-precision_xxx).
* The evaluations subfolder contains MD files that show the final p@k results for the ranking methods, the classes, the 
sensor combinations, the window sizes and the overall results. Note: The MD files of the ranking-methods, classes and 
windows follow the naive aggregation, while for the sensor combinations the informed results are shown. The 
corresponding p@k results are also saved as a json file in the results folder.

*Note*: Due to the limited storage volume, the alignments for all data sets with more than 15 subjects and for all 
experiments with DSF < 1000 were not uploaded. However, these can simply be recalculated.

## In-Out Threshold Attacks
* *Threshold-Attacks_naive*: Contains the results for the In-Out Threshold Attacks of the Slicing-DTW-Attack with the 
naive sensor aggregation.
* *Threshold-Attacks_best*: Contains the results for the In-Out Threshold Attacks of the Slicing-DTW-Attack with the 
informed sensor aggregation.

Structure of the results:
* The recall, precision and f1 score results of all tested thresholds for the corresponding data set and overlap 
(small=0.125, medium=0.5 and high=1.0) are saved in the json files.
* The PDF files show the results of an overlap for all three data sets (WESAD_15, WESAD-cGAN_120 and WESAD-dGAN_120).

## Mitigating DTW-Attacks
* *Privacy-Usability_naive*: Contains the results of the mitigation experiments using naive sensor aggregation.
* *Privacy-Usability_best*: Contains the results of the mitigation experiments using informed sensor aggregation.

Structure of the results:
* 5-LOSO_15real_noised.csv contains the F1 score classification results of the stress detection task.
* privacy_results_DTW-ATTACK.json contains the average p@1 score of the corresponding DTW attack, the standard deviation 
and the p@1 scores for each of the 10 runs.
* privacy_vs_usability.pdf shows the results over all DTW-Attacks plotted.