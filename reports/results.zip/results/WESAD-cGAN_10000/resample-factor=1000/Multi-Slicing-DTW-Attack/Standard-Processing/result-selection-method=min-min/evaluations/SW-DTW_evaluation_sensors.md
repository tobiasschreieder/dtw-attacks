# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'bvp+eda+temp' (decision based on smallest k) 
## Precision@k table: 
| k |bvp | eda | temp | acc | bvp+eda | bvp+temp | bvp+acc | eda+temp | eda+acc | temp+acc | bvp+eda+temp | bvp+eda+acc | bvp+temp+acc | eda+temp+acc | bvp+eda+temp+acc | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 
| 3 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.048 | 0.0 | 0.0 | 0.0 | 0.0 | 
| 5 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.048 | 0.0 | 0.0 | 0.0 | 0.0 | 
| max@k | k = 7149 | k = 9749 | k = 9765 | k = 9760 | k = 7912 | k = 9088 | k = 8643 | k = 8800 | k = 8825 | k = 9712 | k = 8149 | k = 6903 | k = 8978 | k = 8730 | k = 8057 | 

