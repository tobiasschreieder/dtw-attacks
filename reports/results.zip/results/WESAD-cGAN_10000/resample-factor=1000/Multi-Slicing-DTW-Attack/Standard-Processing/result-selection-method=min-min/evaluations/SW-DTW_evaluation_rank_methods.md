# Evaluation of Rank-Methods: 
* Preferred rank-method: 'rank' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.0 | 0.0 | 0.0 |
| 3 | 0.002 | 0.002 | 0.002 |
| 5 | 0.002 | 0.002 | 0.002 |
| max@k | k = 9895 | k = 9765 | k = 9895 |

