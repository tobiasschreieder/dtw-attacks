# Evaluation of Windows: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp+eda+temp+acc' 
* Preferred test-window-size: '34' (decision based on smallest k) 
## Precision@k table: 
| k |34 | 
|---|---|
| 1 | 1.0 | 
| 3 | 1.0 | 
| 5 | 1.0 | 
| max@k | k = 1 | 

