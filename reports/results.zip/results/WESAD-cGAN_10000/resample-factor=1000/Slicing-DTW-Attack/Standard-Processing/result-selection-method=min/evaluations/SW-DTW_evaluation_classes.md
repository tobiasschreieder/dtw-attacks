# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.933 | 0.933 |
| 3 | 0.933 | 0.933 |
| 5 | 0.933 | 0.933 |
| max@k | k = 7228 | k = 4288 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.933 | 0.933 |
| 3 | 0.933 | 0.933 |
| 5 | 0.933 | 0.933 |
| max@k | k = 7228 | k = 7228 |

