# Evaluation of Rank-Methods: 
* Preferred rank-method: 'score' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.604 | 0.933 | 0.769 |
| 3 | 0.649 | 0.933 | 0.791 |
| 5 | 0.671 | 0.933 | 0.802 |
| max@k | k = 7228 | k = 7228 | k = 7228 |

