# Evaluation overall: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp+eda+temp+acc' 
* Calculated with test-window-size: '20' 
## Precision@k table: 
| k | DTW-results naive | DTW-results best | sensor weighted | random guess |
|---|---|---|---|---|
| 1 | 0.0 | 0.0 | 0.0 | 0.0 |
| 3 | 0.0 | 0.0 | 0.0 | 0.0 |
| 5 | 0.0 | 0.0 | 0.0 | 0.001 |
| max@k | k = 9776 | k = 9842 | k = None | k = 9995 |
## Sensor-weighting tables: 
### Table for method: 'non-stress': 
| k | bvp | eda | temp | acc | 
|---|---|---|---|---|
| 1 | 0.4 | 0.2 | 0.2 | 0.2 | 
| 3 | 0.4 | 0.2 | 0.2 | 0.2 | 
| 5 | 0.4 | 0.2 | 0.2 | 0.2 | 
### Table for method: 'stress': 
| k | bvp | eda | temp | acc | 
|---|---|---|---|---|
| 1 | 0.4 | 0.2 | 0.2 | 0.2 | 
| 3 | 0.4 | 0.2 | 0.2 | 0.2 | 
| 5 | 0.4 | 0.2 | 0.2 | 0.2 | 

