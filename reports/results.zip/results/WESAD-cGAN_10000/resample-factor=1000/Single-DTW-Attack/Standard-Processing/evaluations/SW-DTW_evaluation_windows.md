# Evaluation of Windows: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp+eda+temp+acc' 
* Preferred test-window-size: '20' (decision based on smallest k) 
## Precision@k table: 
| k |20 | 
|---|---|
| 1 | 0.0 | 
| 3 | 0.0 | 
| 5 | 0.0 | 
| max@k | k = 9776 | 

