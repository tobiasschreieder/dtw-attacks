# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.0 | 0.0 |
| 3 | 0.0 | 0.0 |
| 5 | 0.0 | 0.0 |
| max@k | k = 9820 | k = 9788 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.0 | 0.0 |
| 3 | 0.0 | 0.0 |
| 5 | 0.0 | 0.0 |
| max@k | k = 9820 | k = 9820 |

