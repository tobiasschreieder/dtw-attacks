# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'bvp+acc' (decision based on smallest k) 
## Precision@k table: 
| k |bvp | eda | temp | acc | bvp+eda | bvp+temp | bvp+acc | eda+temp | eda+acc | temp+acc | bvp+eda+temp | bvp+eda+acc | bvp+temp+acc | eda+temp+acc | bvp+eda+temp+acc | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.005 | 0.001 | 0.0 | 0.002 | 0.003 | 0.003 | 0.005 | 0.001 | 0.002 | 0.001 | 0.003 | 0.003 | 0.004 | 0.001 | 0.003 | 
| 3 | 0.012 | 0.005 | 0.004 | 0.004 | 0.008 | 0.009 | 0.015 | 0.003 | 0.004 | 0.003 | 0.008 | 0.01 | 0.011 | 0.003 | 0.007 | 
| 5 | 0.018 | 0.006 | 0.008 | 0.009 | 0.016 | 0.012 | 0.022 | 0.006 | 0.008 | 0.007 | 0.01 | 0.015 | 0.018 | 0.006 | 0.012 | 
| max@k | k = 986 | k = 999 | k = 1000 | k = 999 | k = 995 | k = 991 | k = 977 | k = 1000 | k = 999 | k = 1000 | k = 992 | k = 971 | k = 991 | k = 1000 | k = 985 | 

