# Evaluation of Windows: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp+eda+temp+acc' 
* Preferred test-window-size: '1' (decision based on smallest k) 
## Precision@k table: 
| k |1 | 
|---|---|
| 1 | 0.003 | 
| 3 | 0.007 | 
| 5 | 0.012 | 
| max@k | k = 985 | 

