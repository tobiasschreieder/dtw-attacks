# Evaluation of Rank-Methods: 
* Preferred rank-method: 'rank' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.002 | 0.002 | 0.002 |
| 3 | 0.007 | 0.007 | 0.007 |
| 5 | 0.012 | 0.011 | 0.012 |
| max@k | k = 999 | k = 999 | k = 999 |

