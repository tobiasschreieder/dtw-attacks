# Evaluation overall: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp+eda+temp+acc' 
* Calculated with test-window-size: '1' 
## Precision@k table: 
| k | DTW-results naive | DTW-results best | sensor weighted | random guess |
|---|---|---|---|---|
| 1 | 0.003 | 0.005 | None | 0.001 |
| 3 | 0.007 | 0.013 | None | 0.003 |
| 5 | 0.012 | 0.021 | None | 0.005 |
| max@k | k = 985 | k = 983 | k = None | k = 1000 |

