# Evaluation overall: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp+eda+temp+acc' 
* Calculated with test-window-size: '34' 
## Precision@k table: 
| k | DTW-results naive | DTW-results best | sensor weighted | random guess |
|---|---|---|---|---|
| 1 | 1.0 | 1.0 | None | 0.001 |
| 3 | 1.0 | 1.0 | None | 0.003 |
| 5 | 1.0 | 1.0 | None | 0.005 |
| max@k | k = 1 | k = 1 | k = None | k = 1000 |

