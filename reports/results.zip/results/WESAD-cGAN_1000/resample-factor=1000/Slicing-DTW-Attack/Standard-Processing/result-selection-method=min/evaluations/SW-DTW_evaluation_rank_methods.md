# Evaluation of Rank-Methods: 
* Preferred rank-method: 'score' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.658 | 0.934 | 0.796 |
| 3 | 0.723 | 0.935 | 0.829 |
| 5 | 0.755 | 0.936 | 0.846 |
| max@k | k = 758 | k = 758 | k = 758 |

