# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.002 | 0.003 |
| 3 | 0.006 | 0.007 |
| 5 | 0.01 | 0.011 |
| max@k | k = 999 | k = 1000 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.003 | 0.002 |
| 3 | 0.007 | 0.006 |
| 5 | 0.01 | 0.01 |
| max@k | k = 999 | k = 999 |

