# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'bvp+eda+acc' (decision based on smallest k) 
## Precision@k table: 
| k |bvp | eda | temp | acc | bvp+eda | bvp+temp | bvp+acc | eda+temp | eda+acc | temp+acc | bvp+eda+temp | bvp+eda+acc | bvp+temp+acc | eda+temp+acc | bvp+eda+temp+acc | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.005 | 0.002 | 0.002 | 0.001 | 0.007 | 0.006 | 0.003 | 0.001 | 0.004 | 0.001 | 0.007 | 0.008 | 0.006 | 0.003 | 0.007 | 
| 3 | 0.013 | 0.005 | 0.004 | 0.004 | 0.017 | 0.013 | 0.014 | 0.007 | 0.009 | 0.003 | 0.015 | 0.015 | 0.012 | 0.006 | 0.017 | 
| 5 | 0.026 | 0.005 | 0.005 | 0.008 | 0.023 | 0.017 | 0.023 | 0.009 | 0.011 | 0.008 | 0.022 | 0.025 | 0.018 | 0.008 | 0.024 | 
| max@k | k = 874 | k = 999 | k = 1000 | k = 998 | k = 994 | k = 990 | k = 948 | k = 1000 | k = 998 | k = 1000 | k = 995 | k = 994 | k = 992 | k = 1000 | k = 992 | 

