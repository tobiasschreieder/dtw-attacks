# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'weighted-mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.005 | 0.002 |
| 3 | 0.012 | 0.007 |
| 5 | 0.018 | 0.01 |
| max@k | k = 999 | k = 999 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.004 | 0.004 |
| 3 | 0.009 | 0.011 |
| 5 | 0.014 | 0.016 |
| max@k | k = 999 | k = 999 |

