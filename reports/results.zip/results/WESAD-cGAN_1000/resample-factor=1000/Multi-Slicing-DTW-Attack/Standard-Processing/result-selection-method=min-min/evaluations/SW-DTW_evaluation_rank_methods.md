# Evaluation of Rank-Methods: 
* Preferred rank-method: 'rank' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.004 | 0.004 | 0.004 |
| 3 | 0.01 | 0.009 | 0.01 |
| 5 | 0.016 | 0.014 | 0.015 |
| max@k | k = 999 | k = 999 | k = 999 |

