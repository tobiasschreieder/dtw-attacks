# Evaluation overall: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp+eda+temp+acc' 
* Calculated with test-window-size: '10' 
## Precision@k table: 
| k | DTW-results naive | DTW-results best | sensor weighted | random guess |
|---|---|---|---|---|
| 1 | 0.007 | 0.005 | None | 0.001 |
| 3 | 0.017 | 0.014 | None | 0.003 |
| 5 | 0.024 | 0.024 | None | 0.005 |
| max@k | k = 992 | k = 973 | k = None | k = 1000 |

