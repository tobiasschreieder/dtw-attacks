# Evaluation of Windows: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp+eda+temp+acc' 
* Preferred test-window-size: '10' (decision based on smallest k) 
## Precision@k table: 
| k |10 | 
|---|---|
| 1 | 0.007 | 
| 3 | 0.017 | 
| 5 | 0.024 | 
| max@k | k = 992 | 

