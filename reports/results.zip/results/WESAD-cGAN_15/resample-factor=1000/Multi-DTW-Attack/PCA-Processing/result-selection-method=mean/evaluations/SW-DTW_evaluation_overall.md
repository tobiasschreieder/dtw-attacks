# Evaluation overall: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp+eda+temp+acc' 
* Calculated with test-window-size: '3' 
## Precision@k table: 
| k | DTW-results naive | DTW-results best | sensor weighted | random guess |
|---|---|---|---|---|
| 1 | 0.133 | 0.133 | 0.133 | 0.067 |
| 3 | 0.267 | 0.267 | 0.267 | 0.2 |
| 5 | 0.267 | 0.267 | 0.267 | 0.333 |
| max@k | k = 15 | k = 15 | k = 15 | k = 15 |
## Sensor-weighting tables: 
### Table for method: 'non-stress': 
| k | pca-1 | 
|---|---|
| 1 | 1.0 | 
| 3 | 1.0 | 
| 5 | 1.0 | 
### Table for method: 'stress': 
| k | pca-1 | 
|---|---|
| 1 | 1.0 | 
| 3 | 1.0 | 
| 5 | 1.0 | 

