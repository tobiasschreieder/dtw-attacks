# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.067 | 0.072 |
| 3 | 0.211 | 0.161 |
| 5 | 0.294 | 0.239 |
| max@k | k = 15 | k = 15 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.07 | 0.068 |
| 3 | 0.186 | 0.197 |
| 5 | 0.266 | 0.279 |
| max@k | k = 15 | k = 15 |

