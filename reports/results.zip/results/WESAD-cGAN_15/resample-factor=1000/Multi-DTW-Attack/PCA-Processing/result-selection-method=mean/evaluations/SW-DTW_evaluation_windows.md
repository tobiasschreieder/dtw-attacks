# Evaluation of Windows: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp+eda+temp+acc' 
* Preferred test-window-size: '3' (decision based on smallest k) 
## Precision@k table: 
| k |1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.048 | 0.115 | 0.133 | 0.115 | 0.019 | 0.067 | 0.019 | 0.085 | 0.085 | 0.067 | 0.067 | 0.0 | 
| 3 | 0.267 | 0.229 | 0.267 | 0.277 | 0.248 | 0.181 | 0.163 | 0.133 | 0.2 | 0.152 | 0.152 | 0.096 | 
| 5 | 0.4 | 0.267 | 0.267 | 0.315 | 0.296 | 0.296 | 0.315 | 0.296 | 0.315 | 0.2 | 0.2 | 0.181 | 
| max@k | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | 

