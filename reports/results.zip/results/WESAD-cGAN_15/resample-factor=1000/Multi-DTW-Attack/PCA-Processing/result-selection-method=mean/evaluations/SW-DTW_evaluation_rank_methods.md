# Evaluation of Rank-Methods: 
* Preferred rank-method: 'rank' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.07 | 0.07 | 0.07 |
| 3 | 0.186 | 0.186 | 0.186 |
| 5 | 0.267 | 0.267 | 0.267 |
| max@k | k = 15 | k = 15 | k = 15 |

