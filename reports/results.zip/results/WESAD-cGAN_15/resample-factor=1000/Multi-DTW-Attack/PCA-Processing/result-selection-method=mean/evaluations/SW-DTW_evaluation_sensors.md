# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'pca-1' (decision based on smallest k) 
## Precision@k table: 
| k |pca-1 | 
|---|---|
| 1 | 0.068 | 
| 3 | 0.197 | 
| 5 | 0.279 | 
| max@k | k = 15 | 

