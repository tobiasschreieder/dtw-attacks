# Evaluation of Windows: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp+eda+temp+acc' 
* Preferred test-window-size: '5' (decision based on smallest k) 
## Precision@k table: 
| k |1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.219 | 0.171 | 0.248 | 0.2 | 0.277 | 0.277 | 0.133 | 0.152 | 0.189 | 0.189 | 0.189 | 0.152 | 
| 3 | 0.419 | 0.467 | 0.437 | 0.485 | 0.485 | 0.467 | 0.371 | 0.323 | 0.371 | 0.389 | 0.323 | 0.419 | 
| 5 | 0.715 | 0.608 | 0.571 | 0.637 | 0.523 | 0.523 | 0.523 | 0.552 | 0.581 | 0.485 | 0.456 | 0.485 | 
| max@k | k = 13 | k = 15 | k = 14 | k = 14 | k = 13 | k = 14 | k = 13 | k = 13 | k = 13 | k = 13 | k = 13 | k = 14 | 

