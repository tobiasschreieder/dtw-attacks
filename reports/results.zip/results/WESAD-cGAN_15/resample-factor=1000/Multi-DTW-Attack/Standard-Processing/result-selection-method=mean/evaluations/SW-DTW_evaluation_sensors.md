# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'bvp+acc' (decision based on smallest k) 
## Precision@k table: 
| k |bvp | eda | temp | acc | bvp+eda | bvp+temp | bvp+acc | eda+temp | eda+acc | temp+acc | bvp+eda+temp | bvp+eda+acc | bvp+temp+acc | eda+temp+acc | bvp+eda+temp+acc | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.238 | 0.06 | 0.133 | 0.074 | 0.155 | 0.175 | 0.267 | 0.107 | 0.07 | 0.057 | 0.144 | 0.155 | 0.261 | 0.101 | 0.2 | 
| 3 | 0.461 | 0.234 | 0.226 | 0.233 | 0.418 | 0.452 | 0.412 | 0.198 | 0.223 | 0.243 | 0.411 | 0.388 | 0.423 | 0.255 | 0.413 | 
| 5 | 0.634 | 0.334 | 0.359 | 0.352 | 0.554 | 0.591 | 0.582 | 0.409 | 0.362 | 0.369 | 0.567 | 0.59 | 0.603 | 0.404 | 0.555 | 
| max@k | k = 14 | k = 15 | k = 15 | k = 15 | k = 14 | k = 15 | k = 13 | k = 15 | k = 15 | k = 15 | k = 15 | k = 14 | k = 15 | k = 15 | k = 15 | 

