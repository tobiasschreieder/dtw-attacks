# Evaluation of Rank-Methods: 
* Preferred rank-method: 'score' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.119 | 0.208 | 0.164 |
| 3 | 0.361 | 0.436 | 0.399 |
| 5 | 0.489 | 0.581 | 0.535 |
| max@k | k = 15 | k = 15 | k = 15 |

