# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.189 | 0.228 |
| 3 | 0.383 | 0.489 |
| 5 | 0.522 | 0.639 |
| max@k | k = 15 | k = 14 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.209 | 0.2 |
| 3 | 0.436 | 0.413 |
| 5 | 0.581 | 0.555 |
| max@k | k = 15 | k = 15 |

