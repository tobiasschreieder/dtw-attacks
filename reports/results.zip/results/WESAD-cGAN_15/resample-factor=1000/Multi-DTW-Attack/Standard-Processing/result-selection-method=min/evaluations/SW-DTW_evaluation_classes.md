# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.117 | 0.15 |
| 3 | 0.244 | 0.339 |
| 5 | 0.383 | 0.483 |
| max@k | k = 15 | k = 15 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.134 | 0.126 |
| 3 | 0.291 | 0.271 |
| 5 | 0.433 | 0.411 |
| max@k | k = 15 | k = 15 |

