# Evaluation of Rank-Methods: 
* Preferred rank-method: 'score' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.081 | 0.133 | 0.107 |
| 3 | 0.294 | 0.292 | 0.293 |
| 5 | 0.436 | 0.433 | 0.435 |
| max@k | k = 15 | k = 15 | k = 15 |

