# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'bvp+acc' (decision based on smallest k) 
## Precision@k table: 
| k |bvp | eda | temp | acc | bvp+eda | bvp+temp | bvp+acc | eda+temp | eda+acc | temp+acc | bvp+eda+temp | bvp+eda+acc | bvp+temp+acc | eda+temp+acc | bvp+eda+temp+acc | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.139 | 0.053 | 0.067 | 0.087 | 0.069 | 0.113 | 0.201 | 0.068 | 0.064 | 0.055 | 0.11 | 0.097 | 0.146 | 0.097 | 0.126 | 
| 3 | 0.401 | 0.196 | 0.19 | 0.212 | 0.342 | 0.29 | 0.342 | 0.203 | 0.208 | 0.203 | 0.287 | 0.329 | 0.326 | 0.217 | 0.271 | 
| 5 | 0.507 | 0.356 | 0.319 | 0.365 | 0.495 | 0.459 | 0.446 | 0.352 | 0.342 | 0.321 | 0.439 | 0.507 | 0.434 | 0.363 | 0.411 | 
| max@k | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 14 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | 

