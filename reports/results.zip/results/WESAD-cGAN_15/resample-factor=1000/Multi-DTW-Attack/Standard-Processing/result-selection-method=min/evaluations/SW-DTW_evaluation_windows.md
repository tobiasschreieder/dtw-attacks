# Evaluation of Windows: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp+eda+temp+acc' 
* Preferred test-window-size: '1' (decision based on smallest k) 
## Precision@k table: 
| k |1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.219 | 0.104 | 0.104 | 0.104 | 0.133 | 0.133 | 0.133 | 0.133 | 0.115 | 0.104 | 0.115 | 0.115 | 
| 3 | 0.371 | 0.352 | 0.352 | 0.237 | 0.189 | 0.2 | 0.267 | 0.285 | 0.256 | 0.237 | 0.219 | 0.285 | 
| 5 | 0.648 | 0.389 | 0.371 | 0.341 | 0.419 | 0.4 | 0.429 | 0.352 | 0.419 | 0.389 | 0.36 | 0.419 | 
| max@k | k = 14 | k = 15 | k = 15 | k = 15 | k = 14 | k = 14 | k = 15 | k = 14 | k = 14 | k = 14 | k = 14 | k = 14 | 

