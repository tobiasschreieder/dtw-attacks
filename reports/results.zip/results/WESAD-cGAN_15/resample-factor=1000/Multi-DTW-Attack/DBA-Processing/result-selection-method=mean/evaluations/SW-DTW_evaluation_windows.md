# Evaluation of Windows: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp+eda+temp+acc' 
* Preferred test-window-size: '3' (decision based on smallest k) 
## Precision@k table: 
| k |1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.219 | 0.237 | 0.285 | 0.285 | 0.219 | 0.219 | 0.219 | 0.219 | 0.171 | 0.219 | 0.123 | 0.123 | 
| 3 | 0.429 | 0.467 | 0.504 | 0.485 | 0.467 | 0.485 | 0.467 | 0.496 | 0.477 | 0.419 | 0.371 | 0.485 | 
| 5 | 0.752 | 0.741 | 0.675 | 0.675 | 0.685 | 0.637 | 0.685 | 0.667 | 0.781 | 0.648 | 0.648 | 0.715 | 
| max@k | k = 14 | k = 8 | k = 9 | k = 9 | k = 9 | k = 9 | k = 10 | k = 10 | k = 12 | k = 13 | k = 13 | k = 12 | 

