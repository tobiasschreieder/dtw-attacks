# Evaluation of Rank-Methods: 
* Preferred rank-method: 'rank' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.233 | 0.233 | 0.233 |
| 3 | 0.464 | 0.464 | 0.464 |
| 5 | 0.708 | 0.708 | 0.708 |
| max@k | k = 14 | k = 14 | k = 14 |

