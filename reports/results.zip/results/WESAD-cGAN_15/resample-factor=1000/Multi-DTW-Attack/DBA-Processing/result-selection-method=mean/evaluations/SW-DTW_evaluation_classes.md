# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.183 | 0.284 |
| 3 | 0.461 | 0.467 |
| 5 | 0.672 | 0.744 |
| max@k | k = 13 | k = 14 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.233 | 0.211 |
| 3 | 0.464 | 0.463 |
| 5 | 0.708 | 0.692 |
| max@k | k = 14 | k = 14 |

