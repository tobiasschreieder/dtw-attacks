# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'dba' (decision based on smallest k) 
## Precision@k table: 
| k |dba | 
|---|---|
| 1 | 0.211 | 
| 3 | 0.463 | 
| 5 | 0.693 | 
| max@k | k = 14 | 

