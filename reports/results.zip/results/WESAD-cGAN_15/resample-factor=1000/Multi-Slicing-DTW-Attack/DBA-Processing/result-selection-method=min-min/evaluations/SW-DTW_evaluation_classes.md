# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.25 | 0.256 |
| 3 | 0.533 | 0.622 |
| 5 | 0.761 | 0.811 |
| max@k | k = 15 | k = 11 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.253 | 0.252 |
| 3 | 0.578 | 0.558 |
| 5 | 0.786 | 0.775 |
| max@k | k = 15 | k = 15 |

