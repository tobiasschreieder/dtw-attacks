# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'dba' (decision based on smallest k) 
## Precision@k table: 
| k |dba | 
|---|---|
| 1 | 0.252 | 
| 3 | 0.558 | 
| 5 | 0.775 | 
| max@k | k = 15 | 

