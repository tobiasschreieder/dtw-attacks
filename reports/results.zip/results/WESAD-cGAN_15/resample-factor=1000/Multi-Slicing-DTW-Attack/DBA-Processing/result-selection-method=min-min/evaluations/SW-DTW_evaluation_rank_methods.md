# Evaluation of Rank-Methods: 
* Preferred rank-method: 'rank' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.253 | 0.253 | 0.253 |
| 3 | 0.578 | 0.578 | 0.578 |
| 5 | 0.786 | 0.786 | 0.786 |
| max@k | k = 15 | k = 15 | k = 15 |

