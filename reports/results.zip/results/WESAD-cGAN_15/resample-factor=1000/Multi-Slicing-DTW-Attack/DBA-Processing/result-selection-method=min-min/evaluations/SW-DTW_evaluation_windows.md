# Evaluation of Windows: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp+eda+temp+acc' 
* Preferred test-window-size: '11' (decision based on smallest k) 
## Precision@k table: 
| k |1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.181 | 0.248 | 0.267 | 0.296 | 0.2 | 0.189 | 0.315 | 0.219 | 0.304 | 0.219 | 0.333 | 0.248 | 
| 3 | 0.352 | 0.523 | 0.648 | 0.541 | 0.427 | 0.6 | 0.544 | 0.6 | 0.619 | 0.685 | 0.589 | 0.571 | 
| 5 | 0.467 | 0.685 | 0.915 | 0.848 | 0.656 | 0.819 | 0.848 | 0.885 | 0.819 | 0.771 | 0.819 | 0.771 | 
| max@k | k = 13 | k = 10 | k = 9 | k = 9 | k = 10 | k = 10 | k = 11 | k = 12 | k = 10 | k = 15 | k = 15 | k = 11 | 

