# Evaluation of Windows: 
* Calculated with rank-method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Calculated with sensor-combination: 'bvp+eda+temp+acc' 
* Preferred test-window-size: '6' (decision based on smallest k) 
## Precision@k table: 
| k |1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 0.0 | 0.133 | 0.2 | 0.019 | 0.085 | 0.211 | 0.096 | 0.096 | 0.096 | 0.019 | 0.019 | 0.163 | 
| 3 | 0.248 | 0.171 | 0.352 | 0.237 | 0.181 | 0.421 | 0.229 | 0.211 | 0.133 | 0.067 | 0.229 | 0.211 | 
| 5 | 0.429 | 0.256 | 0.485 | 0.352 | 0.181 | 0.469 | 0.469 | 0.315 | 0.248 | 0.229 | 0.333 | 0.333 | 
| max@k | k = 15 | k = 15 | k = 15 | k = 14 | k = 15 | k = 14 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | k = 15 | 

