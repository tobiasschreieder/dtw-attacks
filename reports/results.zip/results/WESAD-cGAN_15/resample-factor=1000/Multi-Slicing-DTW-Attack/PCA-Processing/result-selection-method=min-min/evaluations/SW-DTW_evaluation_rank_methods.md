# Evaluation of Rank-Methods: 
* Preferred rank-method: 'rank' (decision based on smallest k) 
## Precision@k table: 
| k | rank | score | mean |
|---|---|---|---|
| 1 | 0.086 | 0.086 | 0.086 |
| 3 | 0.208 | 0.208 | 0.208 |
| 5 | 0.322 | 0.322 | 0.322 |
| max@k | k = 15 | k = 15 | k = 15 |

