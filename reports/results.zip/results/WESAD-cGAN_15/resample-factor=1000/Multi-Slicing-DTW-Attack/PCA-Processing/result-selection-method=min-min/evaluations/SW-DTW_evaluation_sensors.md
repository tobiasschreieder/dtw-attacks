# Evaluation of Sensor-Combinations: 
* Calculated with rank_method: 'score' 
* Calculated with averaging-method: 'weighted-mean' 
* Preferred sensor-combination: 'pca-1' (decision based on smallest k) 
## Precision@k table: 
| k |pca-1 | 
|---|---|
| 1 | 0.095 | 
| 3 | 0.224 | 
| 5 | 0.342 | 
| max@k | k = 15 | 

