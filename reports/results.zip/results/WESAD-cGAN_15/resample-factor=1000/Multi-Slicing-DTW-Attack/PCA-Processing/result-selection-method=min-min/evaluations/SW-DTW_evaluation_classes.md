# Evaluation of Classes: 
* Calculated with rank-method: 'score' 
* Preferred class averaging method: 'weighted-mean' (decision based on smallest k) 
## Evaluation per Class: 
### Precision@k table: 
| k | non-stress | stress |
|---|---|---|
| 1 | 0.106 | 0.067 |
| 3 | 0.245 | 0.172 |
| 5 | 0.367 | 0.278 |
| max@k | k = 15 | k = 15 |
## Overall Evaluation: 
### Precision@k table: 
| k | mean | weighted mean |
|---|---|---|
| 1 | 0.086 | 0.095 |
| 3 | 0.208 | 0.225 |
| 5 | 0.323 | 0.342 |
| max@k | k = 15 | k = 15 |

